<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
	div.white, div.black {
		width:50px;
		height: 50px;
		float:left;
	}
	td {
		width:20px;
		height: 20px;
		display: inline-block;
	}
	.black {
		background-color: #000;
	}
	.container {
		width: 450px;
	}
	</style>
</head>
<body>
	<div class="container">
	<?php
		for($i = 0; $i < 81; $i++){
			if ($i%2 == 0){
				echo '<div class="white"></div> ';
			}
			else {
				echo '<div class="black"></div> ';
			}
		}
		?>
		</div>
		<div>
		<?php
		//avec boucles imbriquées
		echo '<table>';
		for($i = 0; $i < 9; $i++){
			echo '<tr>';
			for($j = 0; $j < 9; $j++){
				if (($i+$j)%2 == 0){
					echo '<td class="white"></td> ';
				}
				else {
					echo '<td class="black"></td> ';
				}
			}
			echo '</tr>';
		}
		echo '</table>';
	?>
	</div>
</body>
</html>

