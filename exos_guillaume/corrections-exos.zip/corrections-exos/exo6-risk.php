<?php
/*
	L'objectif est de simuler une bataille de dés à risque. 

	Les règles : 
	- L'attaquant peut lancer 3 dés simultanément
	- Le défendant peut lancer 2 dés simultanément
	- Le dé le plus fort de l'attaquant est comparé au dé le plus fort du défendant. S'il est plus élevé, l'attaquant gagne. S'il est égal ou plus petit, l'attaquant perd. 
	- On répète ensuite la comparaison avec le second dé le plus fort de chaque joueur. 

	Vous devez donc, à chaque chargement de page, générer 3 dés pour l'attaquant et 2 pour le défendant, et les afficher. 
	Vous devez aussi afficher le nombre de gains réalisés par l'attaquant et/ou le défendant. 

	Indice : stocker les dés de chaque joueur dans des tableaux. 
 */

//contient les scores de chacun
$attackerScore = 0;
$defenderScore = 0;

//génère des dés aléatoirement pour l'attaquant et le défendant
$attackerDice = [mt_rand(1,6), mt_rand(1,6), mt_rand(1,6)];
$defenderDice = [mt_rand(1,6), mt_rand(1,6)];

print_r($attackerDice);
print_r($defenderDice);

//trie les dés du plus fort au moins fort
rsort($attackerDice);
rsort($defenderDice);

//on exécute ce bloc de codes autant de fois qu'il y a de dés...
for($i = 0; $i < count($defenderDice); $i++){

	//extrait le meilleur dés de chacun
	$attackerBest = $attackerDice[$i];
	$defenderBest = $defenderDice[$i];

	//les compare...
	if ($attackerBest > $defenderBest){
		$attackerScore++;
	}
	else {
		$defenderScore++;
	}

}

echo "<br>Attaquant : " . $attackerScore;
echo "<br>Défendant : " . $defenderScore;

